import { Component, inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AuthService } from './services/auth.service';
import { ChatComponent } from './components/chat.component';
import { LoginComponent } from './components/login.component';
import { MsalService } from '@azure/msal-angular';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, ChatComponent, LoginComponent],
  template: `
    <!-- Show chat if logged in, otherwise show login -->
    <ng-container *ngIf="authService.isLoggedIn$ | async; else login">
      <app-chat></app-chat>
    </ng-container>
    <ng-template #login>
      <app-login></app-login>
    </ng-template>
  `,
  styleUrls: ['./app.scss']
})
export class App implements OnInit {
  authService = inject(AuthService);
  private msalService = inject(MsalService);

  async ngOnInit(): Promise<void> {
    // console.log('App initialized - handling MSAL initialization and redirect');
    
    // Make auth service globally accessible for console debugging
    (window as any).authService = this.authService;
    // Development helper logs - commented out for cleaner console
    // console.log('🔧 AuthService available globally as window.authService');
    // console.log('💡 To test if popups are allowed, run: window.authService.testPopups()');
    // console.log('💡 To grant ADX consent, run: window.authService.forceADXConsent()');
    // console.log('💡 To check ADX token status, run: window.authService.hasValidADXToken()');
    // console.log('💡 To refresh ADX token, run: window.authService.refreshADXToken()');
    // console.log('💡 To clear token cache, run: window.authService.clearTokenCache()');
    
    try {
      // Initialize MSAL instance
      await this.msalService.instance.initialize();
      // console.log('MSAL instance initialized successfully');
      
      // Handle redirect promise
      const result = await this.msalService.instance.handleRedirectPromise();
      // console.log('Redirect promise handled:', result);
      
      if (result) {
        console.log('Login successful:', result.account?.username);
      }
    } catch (error) {
      console.error('Error during MSAL initialization/redirect handling:', error);
    }
    
    // Update auth state after initialization
    this.authService.updateAuthState();
    
     // Subscribe to authentication state changes
    this.authService.isLoggedIn$.subscribe(isLoggedIn => {
      // console.log('Authentication state changed:', isLoggedIn);
    });
  }
}

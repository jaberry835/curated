using System.IdentityModel.Tokens.Jwt;
using System.Net.Http.Headers;
using System.Security.Claims;
using Microsoft.IdentityModel.Protocols;
using Microsoft.IdentityModel.Protocols.OpenIdConnect;
using Microsoft.IdentityModel.Tokens;

public class JwtAuthOptions
{
    public required string TenantId { get; set; }
    public required string Audience { get; set; }
    public string AuthorityHost { get; set; } = "https://login.microsoftonline.us"; // Gov: https://login.microsoftonline.us
}

public class TokenReader
{
    private readonly JwtAuthOptions _opts;
    private readonly ConfigurationManager<OpenIdConnectConfiguration> _configManager;

    public TokenReader(JwtAuthOptions opts)
    {
        _opts = opts;
    var authority = $"{_opts.AuthorityHost}/{_opts.TenantId}/v2.0";
        var metadataAddress = $"{authority}/.well-known/openid-configuration";
        _configManager = new ConfigurationManager<OpenIdConnectConfiguration>(
            metadataAddress,
            new OpenIdConnectConfigurationRetriever());
    }

    public async Task<(bool IsAuthenticated, string? Login, string? Error)> GetLoginAsync(IDictionary<string, string> headers)
    {
        // Prefer Easy Auth header if present
        if (headers.TryGetValue("X-MS-CLIENT-PRINCIPAL", out var principalB64))
        {
            try
            {
                var json = System.Text.Encoding.UTF8.GetString(Convert.FromBase64String(principalB64));
                var princ = System.Text.Json.JsonSerializer.Deserialize<ClientPrincipal>(json);
                var upn = princ?.Claims?.FirstOrDefault(c => c.Type is "upn" or "preferred_username" or "name")?.Value;
                if (!string.IsNullOrWhiteSpace(upn))
                    return (true, upn, null);
            }
            catch { /* fall through to JWT */ }
        }

        if (!headers.TryGetValue("Authorization", out var auth) || string.IsNullOrWhiteSpace(auth))
            return (false, null, "Missing Authorization header");

        if (!AuthenticationHeaderValue.TryParse(auth, out var hv) || !"Bearer".Equals(hv.Scheme, StringComparison.OrdinalIgnoreCase) || string.IsNullOrWhiteSpace(hv.Parameter))
            return (false, null, "Invalid Authorization header");

        var token = hv.Parameter;
        try
        {
            var config = await _configManager.GetConfigurationAsync(default);

            // Accept both v2 and v1 issuer formats for the tenant (Gov cloud)
            var v2Issuer = config.Issuer; // e.g. https://login.microsoftonline.us/{tenant}/v2.0
            var v1Issuer = $"{_opts.AuthorityHost.TrimEnd('/')}/{_opts.TenantId}/";
            var stsV1Issuer = $"https://sts.windows.net/{_opts.TenantId}/"; // common v1 issuer

            var validationParameters = new TokenValidationParameters
            {
                // Identity-only: skip audience so tokens for ARM/ADX/custom APIs are accepted
                ValidateAudience = false,

                // Validate issuer and signature
                ValidateIssuer = true,
                ValidIssuers = new[] { v2Issuer, v1Issuer, stsV1Issuer },
                IssuerSigningKeys = config.SigningKeys,
                ValidateIssuerSigningKey = true,
                ValidateLifetime = true,
                ClockSkew = TimeSpan.FromMinutes(5)
            };

            var handler = new JwtSecurityTokenHandler();
            if (!handler.CanReadToken(token))
                return (false, null, "Invalid token");

            var principal = handler.ValidateToken(token, validationParameters, out _);

            var login = principal.FindFirst("upn")?.Value
                        ?? principal.FindFirst("preferred_username")?.Value
                        ?? principal.FindFirst(ClaimTypes.Name)?.Value
                        ?? principal.FindFirst("oid")?.Value;

            return string.IsNullOrWhiteSpace(login) ? (false, null, "No login claim found") : (true, login, null);
        }
        catch (Exception ex)
        {
            return (false, null, $"Token validation failed: {ex.Message}");
        }
    }

    private class ClientPrincipal
    {
        public string? IdentityProvider { get; set; }
        public string? UserId { get; set; }
        public string? UserDetails { get; set; }
        public List<ClientClaim>? Claims { get; set; }
    }

    private class ClientClaim
    {
        public string Type { get; set; } = string.Empty;
        public string Value { get; set; } = string.Empty;
    }
}

using System.Net;
using System.Text;
using System.Linq;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Http;
using Microsoft.Extensions.Logging;

public class GetUserAccessFunction
{
    private readonly TokenReader _tokenReader;
    private readonly UserAccessRepository _repo;
    private readonly ILogger<GetUserAccessFunction> _logger;

    public GetUserAccessFunction(TokenReader tokenReader, UserAccessRepository repo, ILogger<GetUserAccessFunction> logger)
    {
        _tokenReader = tokenReader;
        _repo = repo;
        _logger = logger;
    }

    [Function("GetUserAccess")] 
    public async Task<HttpResponseData> Run(
        [HttpTrigger(AuthorizationLevel.Anonymous, "get", Route = "user-access")] HttpRequestData req,
        FunctionContext context)
    {
        // Collect headers into dictionary (case-insensitive)
        var headers = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        foreach (var h in req.Headers)
        {
            var first = h.Value?.FirstOrDefault();
            if (!string.IsNullOrEmpty(first))
                headers[h.Key] = first!;
        }
        var (isAuth, login, error) = await _tokenReader.GetLoginAsync(headers);
        if (!isAuth || string.IsNullOrWhiteSpace(login))
        {
            var unauthorized = req.CreateResponse(HttpStatusCode.Unauthorized);
            await unauthorized.WriteStringAsync(error ?? "Unauthorized");
            return unauthorized;
        }

        var access = await _repo.GetAccessByLoginAsync(login);
        if (string.IsNullOrWhiteSpace(access))
        {
            var notFound = req.CreateResponse(HttpStatusCode.NotFound);
            await notFound.WriteStringAsync("Not found");
            return notFound;
        }

        var ok = req.CreateResponse(HttpStatusCode.OK);
        ok.Headers.Add("Content-Type", "text/plain; charset=utf-8");
        await ok.WriteStringAsync(access, Encoding.UTF8);
        return ok;
    }
}

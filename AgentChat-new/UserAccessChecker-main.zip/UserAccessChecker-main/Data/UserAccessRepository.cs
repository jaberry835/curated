using Microsoft.Azure.Cosmos;
using Microsoft.Extensions.Configuration;
public class UserAccessRecord
{
    public string id { get; set; } = string.Empty;
    public string? LoginID { get; set; }
    public string? Access { get; set; }
}

public class UserAccessRepository
{
    private readonly CosmosClient _client;
    private readonly string _databaseName;
    private readonly string _containerName;

    public UserAccessRepository(CosmosClient client, IConfiguration config)
    {
        _client = client;
        _databaseName = config["AZURE_COSMOS_DB_DATABASE"] ?? throw new InvalidOperationException("AZURE_COSMOS_DB_DATABASE missing");
        _containerName = config["AZURE_COSMOS_DB_CONTAINER"] ?? config["AZURE_COSMOS_DB_SESSIONS_CONTAINER"] ?? throw new InvalidOperationException("AZURE_COSMOS_DB_CONTAINER missing");
    }

    public async Task<string?> GetAccessByLoginAsync(string login, CancellationToken ct = default)
    {
        var container = _client.GetContainer(_databaseName, _containerName);

        var q = new QueryDefinition("SELECT c.Access FROM c WHERE c.LoginID = @login")
            .WithParameter("@login", login);

        var options = new QueryRequestOptions
        {
            PartitionKey = new PartitionKey(login),
            MaxItemCount = 1
        };

        using var iter = container.GetItemQueryIterator<UserAccessRecord>(q, requestOptions: options);
        while (iter.HasMoreResults)
        {
            var page = await iter.ReadNextAsync(ct);
            var first = page.FirstOrDefault();
            if (first != null)
                return first.Access;
        }
        return null;
    }
}

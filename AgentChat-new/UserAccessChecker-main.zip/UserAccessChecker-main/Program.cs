using Azure.Identity;
using Microsoft.Azure.Cosmos;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;

var host = new HostBuilder()
    .ConfigureFunctionsWorkerDefaults()
    .ConfigureAppConfiguration((ctx, config) =>
    {
        config.AddEnvironmentVariables();
    })
    .ConfigureServices((ctx, services) =>
    {
        var cfg = ctx.Configuration;

        // Cosmos client: prefer key auth if AZURE_COSMOS_DB_KEY is provided; fallback to DefaultAzureCredential
        var cosmosEndpoint = cfg["AZURE_COSMOS_DB_ENDPOINT"] ?? throw new InvalidOperationException("AZURE_COSMOS_DB_ENDPOINT missing");
        var cosmosKey = cfg["AZURE_COSMOS_DB_KEY"];
        services.AddSingleton(sp =>
        {
            if (!string.IsNullOrWhiteSpace(cosmosKey))
            {
                return new CosmosClient(cosmosEndpoint, cosmosKey);
            }
            return new CosmosClient(cosmosEndpoint, new DefaultAzureCredential());
        });

        services.AddSingleton(new JwtAuthOptions
        {
            TenantId = cfg["AZURE_TENANT_ID"]!,
            AuthorityHost = cfg["AZURE_AUTHORITY_HOST"] ?? "https://login.microsoftonline.us",
            Audience = cfg["API_AUDIENCE"]!,
        });

        services.AddSingleton<UserAccessRepository>();
        services.AddSingleton<TokenReader>();
    })
    .Build();

await host.RunAsync();
